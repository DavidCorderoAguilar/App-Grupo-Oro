package com.example.androidmaster.imccalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.cardview.widget.CardView
import com.example.androidmaster.R

class imcCalcuatorActivity : AppCompatActivity() {

    private var isMaleSelected:Boolean = true
    private var isFemaleSelected:Boolean = false
    private lateinit var viewMale:CardView
    private lateinit var viewFemale:CardView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_imc_calcuator)
    initComponent()
        initListener()
    }
    private fun initComponent(){
        viewMale = findViewById(R.id.viewMale)
        viewFemale = findViewById(R.id.viewFemale)
    }
    private fun initListener(){
        viewMale.setOnClickListener{setGenderColor(isMaleSelected)}
        viewFemale.setOnClickListener{setGenderColor(isFemaleSelected)}
    }
    private fun setGenderColor(isViewSelected:Boolean){

    }
}