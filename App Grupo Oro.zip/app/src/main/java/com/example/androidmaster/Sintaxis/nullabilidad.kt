package com.example.androidmaster.Sintaxis

fun main(){
  var name:String? = "david sub"
    println(name?.get(3)  ?: "Es nullo man")
}